/*
** Effects Demo for GSP391
**
** $Id: EffectsDemo.cpp 31 2010-07-21 07:13:04Z Dad $
*/

#define STRICT
#include <windows.h>
#include <assert.h>
#include "Renderer.h"
#include "resource.h"

/*
** TODO:
**		classical look of flat shading versus gouraud versus phong!
**		moving camera using keys & mouse
**		more effects
**		smoother sphere *appearance*
**		allow user to choose new texture
**		fix texture coords for box
**		SAS compliance
*/

/* Globals */
char* sProgramName = "Effects Demo";

static char* sInitialObject = "Ball.x";

static const float cfMinShaderVersion = 2.0f;

static const unsigned int cnScreenWidth = 480;
static const unsigned int cnScreenHeight = 480;

/* Globals */
static char* sObjectFile;
static char* sTextureFile;
static char* sEffectFile;
static char* sTechnique;

static HWND hWnd = NULL;
static ID3DXMesh* pObjectMesh;
static IDirect3DTexture9* pObjectTexture;

static Renderer* pRenderer;

/* Textures */
static char* sTextures[] =
{
	"Glass.jpg",	// load in a defined texture
	"orange.tga",
	"Grass.bmp",
	"conc02.jpg",
	"happy-face.png"
};
static const unsigned NUM_TEXTURES = sizeof(sTextures) / sizeof(sTextures[0]);

/* Effect files */
static char* EffectNames[] =
{
	"Ambient.fx",
	"Toon_Shader.fx",
	"Diffuse.fx",
	"Specular.fx"
};
static const unsigned NUM_EFFECTS = sizeof(EffectNames) / sizeof(EffectNames[0]);

/* Displaying help text? */
static bool bHelping = false;

/* Prototypes */
static void CycleEffect(bool bChange = true);
static void CycleObject(bool bChange = true);
static void CycleShading(bool bChange = true);
static void CycleTexture(bool bChange = true);
static void ToggleWireframe(bool bChange = true);
static void ToggleViewTexture(bool bChange = true);
static void ChooseObject();
static void ChooseEffect();
static char* ChooseFile(char* sTitle, char* sFilter, char* sDefaultExtension);
static void ShowHelp();

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR psCmdLine, int nCmdShow);
HWND OpenWindow(HINSTANCE hInstance, char* sClassName, char* sWindowName);
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);


/*****************************************************\
* WinMain: where everything starts                    *
\*****************************************************/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	char* sClassName = "EffectWindow";

	/* Create the main window */
	hWnd = OpenWindow(hInstance, sClassName, sProgramName);
	if (NULL == hWnd)
	{
		return E_FAIL;
	}
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	/* Create renderer and set up D3D */
	pRenderer = Renderer::GetRenderer(hWnd, cfMinShaderVersion);

	/*
	** Load initial stuff.  All their initial values are set so that the first
	** call cycles or toggles them into those desired for the first dieplay
	*/
	CycleObject();
	CycleTexture();
	CycleEffect();
	CycleShading();
	ToggleWireframe();
	ToggleViewTexture();

	/* Message loop */
	MSG uMsg;
    memset(&uMsg, 0, sizeof(uMsg));
	while (uMsg.message != WM_QUIT)
	{
		/* Is there a message waiting? */
		if (PeekMessage(&uMsg, NULL, 0, 0, PM_REMOVE))
		{
			/* Handle all the waiting messages */
			do
			{
				TranslateMessage(&uMsg);
				DispatchMessage(&uMsg);
			}
			while (PeekMessage(&uMsg, NULL, 0, 0, PM_REMOVE));
		}
        else
		{
			/* No messages waiting: calculate transforms (program-specific) */
			pRenderer->SetTransforms();
			/* Draw one frame */
		    pRenderer->RenderOneFrame(pObjectMesh, pObjectTexture);
		}
		/* Check for more messages */
	}

	pObjectTexture->Release();
	pObjectMesh->Release();

    UnregisterClass(sClassName, hInstance);

	return uMsg.wParam;
}


/*****************************************************\
* OpenWindow: create window class and open a window   *
\*****************************************************/
HWND OpenWindow(HINSTANCE hInstance, char* sClassName, char* sWindowName)
{
	WNDCLASSEX winClass;
	HWND hWnd;

	winClass.lpszClassName = sClassName;
	winClass.cbSize        = sizeof(WNDCLASSEX);
	winClass.style         = CS_HREDRAW | CS_VREDRAW;
	winClass.lpfnWndProc   = WindowProc;
	winClass.hInstance     = hInstance;
	winClass.hIcon	       = ::LoadIcon(hInstance, MAKEINTRESOURCE("IDI_ICON1"));
    winClass.hIconSm	   = ::LoadIcon(hInstance, MAKEINTRESOURCE("IDI_ICON1"));
	winClass.hCursor       = ::LoadCursor(NULL, IDC_ARROW);
	winClass.hbrBackground = (HBRUSH)::GetStockObject(BLACK_BRUSH);
	winClass.lpszMenuName  = NULL;
	winClass.cbClsExtra    = 0;
	winClass.cbWndExtra    = 0;

	if (0 == RegisterClassEx(&winClass))
	{
		return NULL;
	}

	hWnd = ::CreateWindowEx(NULL, sClassName,
							sWindowName,
							WS_OVERLAPPEDWINDOW,
							0, 0,
							cnScreenWidth, cnScreenHeight,
							NULL, NULL, hInstance, NULL);
	return hWnd;
}


/*****************************************************\
* WindowProc: handle incoming events                  *
\*****************************************************/
LRESULT CALLBACK WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
	{
		case WM_DESTROY:
		case WM_CLOSE:
			PostQuitMessage(0);
			return 0;

		case WM_KEYDOWN:
			switch (wParam & 0x7F)
			{
				case VK_MENU:
				case VK_RETURN:
				case VK_F1:
				case '?':
					return 0;

				default:
					if (bHelping)
					{
						pRenderer->TextDone();
						bHelping = false;
					}
					return 1;
			}
			break;

		case WM_KEYUP:
		{
			/* Only sees uppercase letters ... */
			switch (wParam & 0x7F)
			{
				case VK_ESCAPE:
				case VK_END:
				case 'Q':  PostQuitMessage(0); return 0;

				/* E cycles through effects */
				/* O cycles through objects */
				/* S cycles through shading types (flat, gouraud, phong) */
				/* T cycles through textures */
				/* W toggles wireframe */
				/* V toggles viewing textures */
				/* L loads new model */
				/* X loads new effect */

				case 'E':  CycleEffect(); return 0;
				case 'O':  CycleObject(); return 0;
				case 'S':  CycleShading(); return 0;
				case 'T':  CycleTexture(); return 0;
				case 'V':  ToggleViewTexture(); return 0;
				case 'W':  ToggleWireframe(); return 0;
				case 'L':  ChooseObject(); return 0;
				case 'X':  ChooseEffect(); return 0;

				default:  ShowHelp(); return 0;
			}
		}
		/* fall through */

		default:
			return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return 0;
}


/*****************************************************\
* CycleEffect: look at the next available effect      *
\*****************************************************/
void CycleEffect(bool bChange)
{
	static int iCurrent = 0;	/* Which effect shows next? */

	if (! bChange)
	{
		iCurrent = (iCurrent - 1) % NUM_EFFECTS;
	}
	sEffectFile = EffectNames[iCurrent];
	pRenderer->LoadEffect(sEffectFile);
	sTechnique = pRenderer->GetTechniqueName();
	iCurrent = (iCurrent + 1) % NUM_EFFECTS;
}


/*****************************************************\
* CycleObject: look at the next available object      *
\*****************************************************/
void CycleObject(bool bChange)
{
	static const int NUM_OBJECTS = 4;

	static int iCurrent = -1;	/* Which object shows next? */

	if (! bChange)
	{
		iCurrent = (iCurrent - 1) % NUM_OBJECTS;
	}
	switch (iCurrent)
	{
		/* Special case: Always start with the initial object named above */
		case -1:
			pRenderer->LoadXFile(sInitialObject, pObjectMesh);
			break;

		case 0:
			pRenderer->LoadTorus(pObjectMesh);
			break;

		case 1:
			pRenderer->LoadTeapot(pObjectMesh);
			break;

		case 2:
			pRenderer->LoadXFile("Great_Icosahedron.x", pObjectMesh);
			break;

		case 3:
			pRenderer->LoadXFile("Ball.x", pObjectMesh);
	}
	iCurrent = (iCurrent + 1) % NUM_OBJECTS;
}


/*****************************************************\
* CycleShading: look at the next available shade mode *
\*****************************************************/
void CycleShading(bool bChange)
{
	static Renderer::Shading eCurrentShading = Renderer::SHADING_FLAT;

	if (! bChange)
	{
		eCurrentShading = (Renderer::Shading)(((unsigned)eCurrentShading - 1) % Renderer::NUM_SHADING);
	}
	pRenderer->SetShading(eCurrentShading);
	eCurrentShading = (Renderer::Shading)(((unsigned)eCurrentShading + 1) % Renderer::NUM_SHADING);
}


/*****************************************************\
* CycleTexture: look at the next available texture    *
\*****************************************************/
void CycleTexture(bool bChange)
{
	static int iCurrent = 0;

	if (! bChange)
	{
		iCurrent = (iCurrent - 1) % NUM_TEXTURES;
	}
	sTextureFile = sTextures[iCurrent];
	pRenderer->LoadTexture(sTextureFile, pObjectTexture);
	iCurrent = (iCurrent + 1) % NUM_TEXTURES;
}


/*****************************************************\
* ToggleWireframe: turn on or off wireframe display   *
\*****************************************************/
void ToggleWireframe(bool bChange)
{
	static bool bWireframe = false;

	if (! bChange)
	{
		bWireframe = ! bWireframe;
	}
	pRenderer->SetWireframe(bWireframe);
	bWireframe = ! bWireframe;
}


/*****************************************************\
* ToggleViewTexture: turn on or off texture display   *
\*****************************************************/
void ToggleViewTexture(bool bChange)
{
	static bool bTextureMode = false;

	if (!bChange)
	{
		bTextureMode = ! bTextureMode;
	}
	if (bTextureMode)
	{
		pRenderer->ViewTexture(pObjectMesh);
	}
	else
	{
		/* Restore everything */
		CycleObject(false);
		CycleTexture(false);
		CycleEffect(false);
		CycleShading(false);
		ToggleWireframe(false);
	}
	bTextureMode = ! bTextureMode;
}


/*****************************************************\
* ChooseObject: let user choose a new object          *
\*****************************************************/
void ChooseObject()
{
	sObjectFile = ChooseFile("Choose Object Mesh File", "Object Mesh Files\0*.x\0", "x");
	pRenderer->LoadXFile(sObjectFile, pObjectMesh);
}


/*****************************************************\
* ChooseEffect: let user choose a new effect          *
\*****************************************************/
void ChooseEffect()
{
	sEffectFile = ChooseFile("Choose Effect File", "Effect Files\0*.fx\0", "fx");
	pRenderer->LoadEffect(sEffectFile);
	sTechnique = pRenderer->GetTechniqueName();
}


/*****************************************************\
* ChooseFile: let user choose a new file (internal)   *
\*****************************************************/
char* ChooseFile(char* sTitle, char* sFilter, char* sDefaultExtension)
{
	OPENFILENAME ofn;					// common dialog box structure
	static char sFile[MAX_PATH + 1];	// buffer for file name
	ZeroMemory(sFile, sizeof(sFile));

	/* Initialize OPENFILENAME */
	ZeroMemory(&ofn, sizeof(ofn));

	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hWnd;
	ofn.lpstrFilter = sFilter;
	ofn.nFilterIndex = 1;
	ofn.lpstrFile = sFile;
	ofn.nMaxFile = sizeof(sFile);
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = NULL;
	ofn.lpstrTitle = sTitle;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_LONGNAMES;
	ofn.lpstrDefExt = sDefaultExtension;

	/* Display the Open dialog box. */
	GetOpenFileName(&ofn);
	return sFile;
}


/*****************************************************\
* ShowHelp: display key actions                       *
\*****************************************************/
void ShowHelp()
{
	static char* sHelp = 
		"E   cycle effects\n\
		O   cycle objects\n\
		S   cycle shading types\n\
		T   cycle textures\n\
		W  toggle wireframe\n\
		V   toggle texture view\n\
		L   load new model\n\
		X   load new effect\n\
		Q  exit program";
	pRenderer->ShowText(sHelp);
	bHelping = true;
}
