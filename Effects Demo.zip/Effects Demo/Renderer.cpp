/*
** Renderer for Effects Demo for GSP391
**
** $Id: Renderer.cpp 31 2010-07-21 07:13:04Z Dad $
*/

#include "Renderer.h"
#include <stdio.h>
#include <comdef.h>

extern char* sProgramName;

static const D3DXVECTOR3 cvOrigin(0.0f, 0.0f, 0.0f);

/* Vertex declarations for Position Normal TextureCoords */
static D3DVERTEXELEMENT9 PNTDecls[] = 
{
	{0,  0, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
	{0, 12, D3DDECLTYPE_FLOAT3, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL  , 0},
	{0, 24, D3DDECLTYPE_FLOAT2, D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
	D3DDECL_END()
};
typedef struct
{
	D3DXVECTOR3 pos;
	D3DXVECTOR3 norm;
	D3DXVECTOR2 tex0;
} PNTVertex;

/* used in the HR macro */
static UINT hr;
#ifdef _DEBUG
	#ifndef HR
	#define HR(x)                                      \
	{                                                  \
		HRESULT hr = x;                                \
		if(FAILED(hr))                                 \
		{                                              \
			DXTrace(__FILE__, __LINE__, hr, #x, TRUE); \
		}                                              \
	}
	#endif
#else
	#ifndef HR
	#define HR(x) x;
	#endif
#endif 


Renderer::Renderer(HWND hWnd, const float cfMinShaderVersion)
{
	SetShaderVersion(cfMinShaderVersion);
	InitializeDirect3D(hWnd);

	/* Create font objects */
	D3DXCreateFont(m_pD3DDevice, 30, 0, FW_BOLD, 0, FALSE,
				   DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
				   DEFAULT_QUALITY, FF_SWISS, "", &m_pFont);
	D3DXCreateFont(m_pD3DDevice, 24, 0, FW_BOLD, 0, FALSE,
				   DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
				   DEFAULT_QUALITY, FF_SWISS, "", &m_pHelpFont);

	m_fSize = 10.0f;
	m_vCenter = cvOrigin;
	m_bShowingText = false;
}


void Renderer::SetShaderVersion(const float fMinShaderVersion)
{
	unsigned uVersion = (unsigned)(10.0f * (fMinShaderVersion + 0.05f));
	unsigned uMajor = uVersion / 10;
	unsigned uMinor = uVersion % 10;
	m_cdwMinShaderVersion = D3DPS_VERSION(uMajor, uMinor);
}


Renderer::~Renderer()
{
	Cleanup();
}


Renderer* Renderer::GetRenderer(HWND hWnd, const float fMinShaderVersion)
{
	static Renderer theRenderer(hWnd, fMinShaderVersion);
	return &theRenderer;
}


/*****************************************************\
* InitializeDirect3D                                  *
\*****************************************************/
void Renderer::InitializeDirect3D(HWND hWnd)
{
	if (hWnd == NULL)
	{
		return;
	}
	m_hWnd = hWnd;

	/* Set screen width and height to client rectangle */
	RECT clientRect;
	if (! ::GetClientRect(m_hWnd, &clientRect))
	{
		return;
	}
	m_fScreenWidth = (float)(clientRect.right - clientRect.left);
	m_fScreenHeight = (float)(clientRect.bottom - clientRect.top);

	IDirect3D9* pD3D = Direct3DCreate9(D3D_SDK_VERSION);
	if (NULL == pD3D)
	{
		CloseWithMessage("Direct3DCreate9() failed");
		/*NOTREACHED*/
	}

    D3DDISPLAYMODE d3ddm;
	HR(pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm));

	HR(pD3D->CheckDeviceFormat(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, d3ddm.Format,
							   D3DUSAGE_DEPTHSTENCIL, D3DRTYPE_SURFACE, D3DFMT_D16));

	D3DCAPS9 d3dCaps;
	HR(pD3D->GetDeviceCaps(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, &d3dCaps));

	/*
	** Use hardware vertex processing if supported and shader version acceptable,
	** otherwise default to software
	*/
	DWORD dwBehaviorFlags = 0;
	if ((d3dCaps.VertexProcessingCaps != 0) && (d3dCaps.PixelShaderVersion >= m_cdwMinShaderVersion))
	{
		dwBehaviorFlags |= D3DCREATE_HARDWARE_VERTEXPROCESSING;
	}
	else
	{
		dwBehaviorFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;
	}

	/* All system checks passed, create the D3D device */
	D3DPRESENT_PARAMETERS d3dpp;
	memset(&d3dpp, 0, sizeof(d3dpp));
    d3dpp.BackBufferFormat       = d3ddm.Format;
	d3dpp.SwapEffect             = D3DSWAPEFFECT_DISCARD;
	d3dpp.Windowed               = TRUE;
    d3dpp.EnableAutoDepthStencil = TRUE;
    d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
    d3dpp.PresentationInterval   = D3DPRESENT_INTERVAL_ONE;

	HR(pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL,
						  m_hWnd, dwBehaviorFlags, &d3dpp, &m_pD3DDevice));

	/* No longer needed, release it */
	pD3D->Release();
}


/*****************************************************\
* CloseWithMessage                                    *
\*****************************************************/
void Renderer::CloseWithMessage(char* sWhere, HRESULT hr)
{
    /* Display the error message and exit the process */
	if (NULL != sWhere)
	{
		::MessageBox(m_hWnd, _com_error(hr).ErrorMessage(), sWhere, MB_ICONSTOP);
	}
#ifdef _DEBUG
	__asm { int 3 }
#endif
	Cleanup();
    ExitProcess(-1);
	/*NOTREACHED*/
}


/*****************************************************\
* LoadMesh                                           *
\*****************************************************/
void Renderer::LoadMesh(ID3DXMesh*& pMesh, ID3DXBuffer* pAdjacency)
{
	/* Clone the mesh, ensuring that it has room for texture coordinates */
	ID3DXMesh* theClone = NULL;
	HR(pMesh->CloneMesh(D3DXMESH_SYSTEMMEM, PNTDecls, m_pD3DDevice, &theClone));
	pMesh->Release();
	pMesh = theClone;

#if 0
	/* Recompute the normals */
	HR(D3DXComputeNormals(pMesh, (DWORD*)pAdjacency->GetBufferPointer());)
#endif

	/* texture coordinates are generated when the mesh is scaled */

	/* Optimize */
	HR(pMesh->OptimizeInplace(D3DXMESHOPT_ATTRSORT | D3DXMESHOPT_COMPACT | D3DXMESHOPT_VERTEXCACHE,
							  (DWORD*)pAdjacency->GetBufferPointer(), 0, 0, 0));

	/* Done with adjacency buffer */
	pAdjacency->Release();

	/* Adjust mesh or save bounds */
	if ((m_fSize <= 0.0f) /* || (D3DXVec3LengthSq(&m_vCenter) <= 0.1f) */)
	{
		HR(CalcBounds(pMesh, &m_vCenter, &m_fSize));
	}
	else
	{
		HR(AdjustMesh(pMesh, &m_vCenter, &m_fSize));
	}
}


void Renderer::LoadXFile(char* sMeshFilename, ID3DXMesh*& pMesh)
{
	if (NULL != pMesh)
	{
		pMesh->Release();
	}
	pMesh = NULL;

	ID3DXBuffer* pAdjacency = NULL;		/* required for OptimizeInPlace */
	ID3DXBuffer* pMaterials = NULL;
	ID3DXBuffer* pEffectsInstances = NULL;
	DWORD dwNumMaterials = 0;
	HR(D3DXLoadMeshFromX(sMeshFilename, D3DXMESH_MANAGED, m_pD3DDevice,
						 &pAdjacency, &pMaterials, &pEffectsInstances, &dwNumMaterials, &pMesh));
	LoadMesh(pMesh, pAdjacency);
}


void Renderer::LoadTeapot(ID3DXMesh*& pMesh)
{
	/* Zero mesh */
	if (NULL != pMesh)
	{
		pMesh->Release();
	}
	pMesh = NULL;

	/* Load and optimize the mesh */
	ID3DXBuffer* pAdjacency = NULL;		/* required for OptimizeInPlace */
	HR(D3DXCreateTeapot(m_pD3DDevice, &pMesh, &pAdjacency));
	LoadMesh(pMesh, pAdjacency);
	/* teapot is small */
	HR(ScaleMesh(pMesh, 1.5f, cvOrigin));
}


void Renderer::LoadTorus(ID3DXMesh*& pMesh)
{
	/* Zero mesh */
	if (NULL != pMesh)
	{
		pMesh->Release();
	}
	pMesh = NULL;

	/* Load and optimize the mesh */
	ID3DXBuffer* pAdjacency = NULL;		/* required for OptimizeInPlace */
	HR(D3DXCreateTorus(m_pD3DDevice, 0.33f, 1.0f, 16, 16, &pMesh, &pAdjacency));
	LoadMesh(pMesh, pAdjacency);
}


/*****************************************************\
* LoadEffect                                          *
\*****************************************************/
HRESULT Renderer::LoadEffect(char* sEffectFile)
{
	
	/* Load the HLSL effect file */
	LPD3DXBUFFER pdxCompileErrors;
	ID3DXEffect* pEffect;
	hr = D3DXCreateEffectFromFile(m_pD3DDevice, sEffectFile,
								  NULL, NULL, NULL, NULL, &pEffect, &pdxCompileErrors);
	if (FAILED(hr))
	{
		if (NULL != pdxCompileErrors)
		{
			::MessageBox(m_hWnd, (char*)pdxCompileErrors->GetBufferPointer(),
						 "Shader compilation errors", MB_ICONSTOP);
			CloseWithMessage(NULL);
			/*NOTREACHED*/
		}
		return hr;
	}

	if (m_pEffect != NULL)
	{
		m_pEffect->Release();
	}
	m_pEffect = pEffect;

	/* choose the first technique (default) in the file */
	/* TODO: select techniques by name?  Show all the names and let choose? */
	HR(m_pEffect->FindNextValidTechnique(NULL, &m_hTechnique));
	HR(m_pEffect->GetTechniqueDesc(m_hTechnique, &m_hTechniqueDesc));

	return S_OK;
}


/*****************************************************\
* SetTransforms                                       *
\*****************************************************/
void Renderer::SetTransforms()
{
	/* Set the View matrix */
	D3DXVECTOR3 vPosition(0.0f, 0.0f, -50.0f);
	D3DXVECTOR3 vTarget(0.0f, 0.0f, 0.0f);
	D3DXVECTOR3 vUp(0.0f, 1.0f, 0.0f);
	D3DXMatrixLookAtLH(&m_matView, &vPosition, &vTarget, &vUp);

	/* Set the Projection matrix */
	D3DXMatrixPerspectiveFovLH(&m_matProj, (D3DX_PI /4), (m_fScreenWidth / m_fScreenHeight), 1.0f, 100.0f);

	/* Disable automatic lighting */
	m_pD3DDevice->SetRenderState(D3DRS_LIGHTING, false);

	/* Set some render states to determine texture quality */
	m_pD3DDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pD3DDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pD3DDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
}


/*****************************************************\
* Cleanup                                             *
\*****************************************************/
void Renderer::Cleanup()
{
	/* Release the objects */
	if (NULL != m_pFont)
	{
		m_pFont->Release();
	}
	if (NULL != m_pHelpFont)
	{
		m_pHelpFont->Release();
	}
	if (NULL != m_pEffect)
	{
		m_pEffect->Release();
	}
	if (NULL != m_pD3DDevice)
	{
		m_pD3DDevice->Release();
	}
}


/*****************************************************\
* RenderOneFrame                                      *
\*****************************************************/
void Renderer::RenderOneFrame(ID3DXMesh* pMesh, IDirect3DTexture9* pTexture)
{
	m_pD3DDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0x00000000, 1.0f, 0);
    m_pD3DDevice->BeginScene();

	/* Set the world matrix */
	D3DXMATRIX matWorld;
	D3DXMatrixIdentity(&matWorld);

	/* Set dynamic shader variables */
// Unhighlight this to set the paramters for the original effect files, and unhighlight the one for the toon shader below
/*
	m_pEffect->SetTechnique(m_hTechnique);
	m_pEffect->SetMatrix("worldViewProj", &(matWorld * m_matView * m_matProj));
	m_pEffect->SetMatrix("world", &matWorld);
	m_pEffect->SetTexture("modelTexture", pTexture);

	m_pEffect->SetInt("fillMode", m_dwFillMode);
	m_pEffect->SetInt("shadeMode", m_dwShadeMode);

*/
	// Implements the toon shader
// /*
	D3DXMATRIX WIT;
	D3DXMatrixMultiply(&WIT, &m_matView, &m_matProj);
	D3DXMatrixMultiply(&WIT, &WIT, &matWorld);

	D3DXMatrixInverse(&WIT, 0, &WIT);
	D3DXMatrixTranspose(&WIT, &WIT);

	m_pEffect->SetTechnique("Toon");
	m_pEffect->SetMatrix("World", &matWorld);
	m_pEffect->SetMatrix("View", &m_matView);
	m_pEffect->SetMatrix("Projection", &m_matProj);
	m_pEffect->SetMatrix("WorldInverseTranspose", &WIT);
	m_pEffect->SetTexture("Texture", pTexture);
	
//	*/
	
	/* Begin the shader pass(es) */
	UINT Passes;
	m_pEffect->Begin(&Passes, 0);
	for (UINT Pass = 0; Pass < Passes; ++Pass)
	{
		m_pEffect->BeginPass(Pass);

		/* Render the ball */
		pMesh->DrawSubset(0);

		m_pEffect->EndPass();
	}
	m_pEffect->End();

	DisplayInfo();

    m_pD3DDevice->EndScene();
    m_pD3DDevice->Present(NULL, NULL, NULL, NULL);
}


void Renderer::LoadTexture(char* sTextureFile, IDirect3DTexture9*& pTexture)
{
	HR(D3DXCreateTextureFromFile(m_pD3DDevice, sTextureFile, &pTexture));
}


void Renderer::DisplayInfo()
{
	/* Create white color for text */
	static D3DCOLOR whiteColor = D3DCOLOR_ARGB(255, 255, 255,255);

	if (m_bShowingText)
	{
		/* Center left-justified text on screen */
		RECT textRect = { 2, 6, (int)m_fScreenWidth - 2, (int)m_fScreenHeight - 10 };
		m_pHelpFont->DrawText(NULL, m_sHelpText, -1, &textRect,
							  DT_CALCRECT | DT_LEFT | DT_TOP | DT_NOCLIP, whiteColor);
		/* Change the rectangle to be screen-centered */
		const int ciWidth = textRect.right - textRect.left;
		const int ciHeight = textRect.bottom - textRect.top;
		const int ciDx = ((int)m_fScreenWidth - ciWidth) / 2;
		const int ciDy = ((int)m_fScreenHeight - ciHeight) / 2;
		::OffsetRect(&textRect, ciDx, ciDy);
		m_pHelpFont->DrawText(NULL, m_sHelpText, -1, &textRect,
							  DT_LEFT | DT_TOP | DT_NOCLIP, whiteColor);
	}
	else
	{
		/* Create a rectangle to indicate where it goes on the screen */
		RECT textRect = {2, 10, (int)m_fScreenWidth - 2, 30};

		char* sShadeMode;
		switch (m_dwShadeMode)
		{
			case D3DSHADE_FLAT:
				sShadeMode = "Flat";
				break;

			case D3DSHADE_GOURAUD:
				sShadeMode = "Gouraud";
				break;

			case D3DSHADE_PHONG:
				sShadeMode = "Phong";
		}

		char sInfo[50];
		sprintf_s(sInfo, sizeof(sInfo), "%s (%s)", m_hTechniqueDesc.Name, sShadeMode);

		/* Draw the text */
		m_pFont->DrawText(NULL, sInfo, -1, &textRect,
						  DT_SINGLELINE | DT_CENTER | DT_VCENTER | DT_NOCLIP, whiteColor);
	}
}


HRESULT Renderer::CalcBounds(ID3DXMesh* pMesh, D3DXVECTOR3* pvLocation, float* pfSize)
{
	if (NULL == pMesh)
	{
		return D3DERR_INVALIDCALL;
	}

	/* Get vertex count */
	DWORD dwNumVerts = pMesh->GetNumVertices();

	/* Get FVF flags */
	DWORD dwFVFSize = D3DXGetFVFVertexSize(pMesh->GetFVF());

	/* Lock vertex buffer */
	BYTE* ptr;
	HR(pMesh->LockVertexBuffer(0, (LPVOID*)&ptr));

	/* Compute bounding sphere */
	HR(D3DXComputeBoundingSphere((D3DXVECTOR3*)ptr, dwNumVerts, dwFVFSize, pvLocation, pfSize));

	/* Unlock vertex buffer */
	HR(pMesh->UnlockVertexBuffer());

	return S_OK;
}


HRESULT Renderer::ScaleMesh(ID3DXMesh* pMesh, float fScale, D3DXVECTOR3 vOffset)
{
	/* Fail if no mesh pointer provided */
	if (NULL == pMesh)
	{
		return D3DERR_INVALIDCALL;
	}

	D3DXVECTOR3 vCenter;
	float fSize;
	HR(CalcBounds(pMesh, &vCenter, &fSize));

	/* Get vertex count */
	DWORD dwNumVerts = pMesh->GetNumVertices();

	/* Lock vertex buffer */
	PNTVertex* vertices = NULL;
	HR(pMesh->LockVertexBuffer(0, (LPVOID*)&vertices));
	
	/* Scale the vertices & generate texture coordinates */
	for (DWORD i = 0; i < dwNumVerts; ++i)
	{
		/* Get pointer to vertex */
		PNTVertex* pVert = &(vertices[i]);
		D3DXVECTOR3* p = &(pVert->pos);

		/* Scale vertex */
		*p += vOffset;
		*p *= fScale;

		/* Spherical texture coordinates */
		float theta = atan2f(p->z, p->x);
		float phi   = acosf(p->y / sqrtf((p->x * p->x) + (p->y * p->y) + (p->z * p->z)));

		/*
		** Phi and theta give the texture coordinates, but are not
		** in the range [0, 1], so scale them into that range.
		*/
		pVert->tex0.x = theta / (2.0f * D3DX_PI);
		pVert->tex0.y = phi   / D3DX_PI;
	}

	/* Unlock vertex buffer */
	HR(pMesh->UnlockVertexBuffer());

	return S_OK;
}


HRESULT Renderer::AdjustMesh(ID3DXMesh* pMesh, D3DXVECTOR3* pvDesiredLocation, float* pfDesiredSize)
{
	/* calculate bounds of mesh */
	D3DXVECTOR3 vLocation;
	float fSize;
	HR(CalcBounds(pMesh, &vLocation, &fSize));

	/* calculate scaling factor */
	float fScale = *pfDesiredSize / fSize;

	/* calculate offset if nothing requested */
	D3DXVECTOR3 vOffset = (NULL != pvDesiredLocation) ? (*pvDesiredLocation - vLocation) : cvOrigin;

	/* scale and offset mesh */
	HR(ScaleMesh(pMesh, fScale, vOffset));

	return hr;
}


void Renderer::SetShading(Shading eShading)
{
	switch (eShading)
	{
		case SHADING_FLAT:
			m_dwShadeMode = D3DSHADE_FLAT;
			break;

		case SHADING_GOURAUD:
			m_dwShadeMode = D3DSHADE_GOURAUD;
			break;

		case SHADING_PHONG:
			m_dwShadeMode = D3DSHADE_PHONG;
	}
}


void Renderer::SetWireframe(bool bWireframe)
{
	m_dwFillMode = (bWireframe) ?  D3DFILL_WIREFRAME : D3DFILL_SOLID;
}


void Renderer::ViewTexture(ID3DXMesh*& pMesh)
{
	/* Load an axially aligned cube ;) */

	/* Zero mesh */
	if (NULL != pMesh)
	{
		pMesh->Release();
	}
	pMesh = NULL;

	/* Load and optimize the mesh */
	ID3DXBuffer* pAdjacency = NULL;		/* required for OptimizeInPlace */
	HR(D3DXCreateBox(m_pD3DDevice, m_fSize, m_fSize, m_fSize, &pMesh, &pAdjacency));
	LoadMesh(pMesh, pAdjacency);
	ScaleMesh(pMesh, 2.0f, cvOrigin);
}


char* Renderer::GetTechniqueName()
{
	return (char*)m_hTechniqueDesc.Name;
}


void Renderer::TextDone()
{
	m_bShowingText = false;
}


void Renderer::ShowText(char *sMessage)
{
	m_sHelpText = sMessage;
	m_bShowingText = true;
}
