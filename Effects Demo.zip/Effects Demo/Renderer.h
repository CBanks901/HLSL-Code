#pragma once

#include <d3d9.h>
#pragma comment(lib, "d3d9.lib")
#include <d3dx9.h>
#pragma comment(lib, "d3dx9.lib")
#include <dxerr.h>
#pragma comment(lib, "dxerr.lib")

/* Allow only one Renderer to exist via Singleton design pattern */

class Renderer
{
public:
	static Renderer* GetRenderer(HWND hWnd, const float cfMinShaderVersion);
	virtual ~Renderer();

	void LoadXFile(char* sMeshFilename, ID3DXMesh*& pMesh);
	void LoadTeapot(ID3DXMesh*& pMesh);
	void LoadTorus(ID3DXMesh*& pMesh);

	void LoadTexture(char* sTextureFile, IDirect3DTexture9*& pTexture);
	void ViewTexture(ID3DXMesh*& pMesh);
	HRESULT LoadEffect(char* sEffectFile);

	void SetTransforms();
	void SetWireframe(bool bWireframe);
	char* GetTechniqueName();

	typedef enum
	{
		SHADING_FLAT = 0,
		SHADING_GOURAUD,
		SHADING_PHONG,
		NUM_SHADING
	} Shading;
	void SetShading(Shading eShading);

	void ShowText(char* sMessage);
	void TextDone();

	void RenderOneFrame(ID3DXMesh* pMesh, IDirect3DTexture9* pTexture);

private:
	DWORD m_cdwMinShaderVersion;
	IDirect3DDevice9* m_pD3DDevice;
	ID3DXEffect* m_pEffect;
	D3DXMATRIX m_matView;
	D3DXMATRIX m_matProj;
	HWND m_hWnd;
	float m_fScreenWidth;
	float m_fScreenHeight;
	D3DXHANDLE m_hTechnique;
	D3DXTECHNIQUE_DESC m_hTechniqueDesc;
	LPD3DXFONT m_pFont;
	LPD3DXFONT m_pHelpFont;
	D3DXVECTOR3 m_vCenter;
	float m_fSize;
	DWORD m_dwFillMode;
	DWORD m_dwShadeMode;
	bool m_bShowingText;
	char* m_sHelpText;

private:
	Renderer(HWND hWnd, const float cfMinShaderVersion);
	Renderer& operator=(const Renderer& rhs);

	void InitializeDirect3D(HWND hWnd);
	void CloseWithMessage(char* sMessage, HRESULT hr = E_FAIL);
	void SetShaderVersion(const float cfMinShaderVersion);
	void Cleanup();
	void DisplayInfo();
	HRESULT CalcBounds(ID3DXMesh* pMesh, D3DXVECTOR3* pvLocation, float* pfSize);
	HRESULT ScaleMesh(ID3DXMesh* pMesh, float fScale, D3DXVECTOR3 vOffset);
	HRESULT AdjustMesh(ID3DXMesh* pMesh, D3DXVECTOR3* pvDesiredLocation, float* pfDesiredSize);
	void LoadMesh(ID3DXMesh*& pMesh, ID3DXBuffer* pAdjacency);
};
